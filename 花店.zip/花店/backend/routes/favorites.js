const express = require('express');
const router = express.Router();
const products = require('../data/products');

// 收藏数据存储在内存中
const favorites = {};

// 添加商品到收藏
router.post('/add', (req, res) => {
  const { userId, productId } = req.body;
  
  if (!userId || !productId) {
    return res.status(400).json({ error: 'ユーザーIDと商品IDが必要です' });
  }
  
  if (!favorites[userId]) {
    favorites[userId] = [];
  }
  
  const productIdInt = parseInt(productId);
  
  // 检查是否已收藏
  if (favorites[userId].includes(productIdInt)) {
    return res.status(400).json({ error: '既にお気に入りに登録されています' });
  }
  
  favorites[userId].push(productIdInt);
  
  res.json({ success: true, favorites: favorites[userId] });
});

// 从收藏中删除商品
router.delete('/remove', (req, res) => {
  const { userId, productId } = req.body;
  
  if (!userId || !productId) {
    return res.status(400).json({ error: 'ユーザーIDと商品IDが必要です' });
  }
  
  if (!favorites[userId]) {
    return res.status(404).json({ error: 'お気に入りが見つかりません' });
  }
  
  const productIdInt = parseInt(productId);
  favorites[userId] = favorites[userId].filter(id => id !== productIdInt);
  
  res.json({ success: true, favorites: favorites[userId] });
});

// 检查商品是否已收藏
router.get('/check/:userId/:productId', (req, res) => {
  const { userId, productId } = req.params;
  const userFavorites = favorites[userId] || [];
  const isFavorite = userFavorites.includes(parseInt(productId));
  res.json({ isFavorite });
});

// 获取商品的总收藏数（模拟随机喜欢值）- 必须放在 /:userId 之前
router.get('/product/:productId/count', (req, res) => {
  const productId = parseInt(req.params.productId);
  // 模拟随机喜欢值（实际应用中应从数据库获取）
  const randomCount = Math.floor(Math.random() * 100) + 20;
  res.json({ count: randomCount });
});

// 获取用户收藏的商品 - 必须放在最后（更通用的路由）
router.get('/:userId', (req, res) => {
  const userId = req.params.userId;
  const userFavorites = favorites[userId] || [];
  res.json(userFavorites);
});

module.exports = router;

