const express = require('express');
const router = express.Router();
const products = require('../data/products');

// 获取所有商品
router.get('/', (req, res) => {
  res.json(products);
});

// 根据ID获取单个商品
router.get('/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const product = products.find(p => p.id === id);
  
  if (!product) {
    return res.status(404).json({ error: '商品が見つかりません' });
  }
  
  res.json(product);
});

module.exports = router;

