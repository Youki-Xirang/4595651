const express = require('express');
const router = express.Router();
const products = require('../data/products');

// 订单数据存储在内存中
const orders = {
  1: [ // 山田花子
    { id: 1, date: '2024-01-15', items: [{ productId: 1, quantity: 2 }, { productId: 3, quantity: 1 }], total: 9200 },
    { id: 2, date: '2024-02-20', items: [{ productId: 5, quantity: 1 }], total: 3200 },
    { id: 3, date: '2024-03-10', items: [{ productId: 2, quantity: 1 }, { productId: 4, quantity: 2 }], total: 7800 }
  ],
  2: [ // 田中太郎
    { id: 1, date: '2024-01-18', items: [{ productId: 7, quantity: 1 }], total: 4500 },
    { id: 2, date: '2024-02-28', items: [{ productId: 6, quantity: 3 }, { productId: 8, quantity: 1 }], total: 7500 }
  ],
  3: [ // 鈴木美咲
    { id: 1, date: '2024-01-22', items: [{ productId: 2, quantity: 2 }, { productId: 5, quantity: 1 }], total: 8800 },
    { id: 2, date: '2024-03-05', items: [{ productId: 1, quantity: 1 }, { productId: 3, quantity: 2 }], total: 7900 },
    { id: 3, date: '2024-03-18', items: [{ productId: 7, quantity: 1 }, { productId: 4, quantity: 1 }], total: 7000 }
  ]
};

// 获取用户订单历史
router.get('/:userId', (req, res) => {
  const userId = req.params.userId;
  const userOrders = orders[userId] || [];
  
  // 添加商品详细信息
  const ordersWithDetails = userOrders.map(order => ({
    ...order,
    items: order.items.map(item => {
      const product = products.find(p => p.id === item.productId);
      return {
        ...item,
        productName: product ? product.name : '不明な商品',
        productPrice: product ? product.price : 0
      };
    })
  }));
  
  res.json(ordersWithDetails);
});

// 创建新订单（结账时调用）
router.post('/create', (req, res) => {
  const { userId, items, total } = req.body;
  
  if (!userId || !items || !total) {
    return res.status(400).json({ error: '必要な情報が不足しています' });
  }
  
  if (!orders[userId]) {
    orders[userId] = [];
  }
  
  const newOrder = {
    id: orders[userId].length + 1,
    date: new Date().toISOString().split('T')[0],
    items: items,
    total: total
  };
  
  orders[userId].unshift(newOrder); // 添加到开头
  
  res.json({ success: true, order: newOrder });
});

module.exports = router;

