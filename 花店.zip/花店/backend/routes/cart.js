const express = require('express');
const router = express.Router();

// 购物车存储在内存中（在实际应用中应使用数据库）
const carts = {};

// 获取用户购物车
router.get('/:userId', (req, res) => {
  const userId = req.params.userId;
  const cart = carts[userId] || [];
  res.json(cart);
});

// 添加商品到购物车
router.post('/add', (req, res) => {
  const { userId, productId, quantity = 1 } = req.body;
  
  if (!userId || !productId) {
    return res.status(400).json({ error: 'ユーザーIDと商品IDが必要です' });
  }
  
  if (!carts[userId]) {
    carts[userId] = [];
  }
  
  const existingItem = carts[userId].find(item => item.productId === productId);
  
  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    carts[userId].push({ productId, quantity });
  }
  
  res.json({ success: true, cart: carts[userId] });
});

// 从购物车删除商品
router.delete('/remove', (req, res) => {
  const { userId, productId } = req.body;
  
  if (!userId || !productId) {
    return res.status(400).json({ error: 'ユーザーIDと商品IDが必要です' });
  }
  
  if (!carts[userId]) {
    return res.status(404).json({ error: 'カートが見つかりません' });
  }
  
  carts[userId] = carts[userId].filter(item => item.productId !== productId);
  
  res.json({ success: true, cart: carts[userId] });
});

// 清空购物车（结账时使用）
router.delete('/clear/:userId', (req, res) => {
  const userId = req.params.userId;
  carts[userId] = [];
  res.json({ success: true });
});

module.exports = router;

