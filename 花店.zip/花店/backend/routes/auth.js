const express = require('express');
const router = express.Router();
const users = require('../data/users');

// 用户登录
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  if (!username || !password) {
    return res.status(400).json({ error: 'ユーザー名とパスワードを入力してください' });
  }
  
  const user = users.find(u => u.username === username && u.password === password);
  
  if (!user) {
    return res.status(401).json({ error: 'ユーザー名またはパスワードが正しくありません' });
  }
  
  res.json({
    success: true,
    user: {
      id: user.id,
      username: user.username,
      name: user.name
    }
  });
});

module.exports = router;

