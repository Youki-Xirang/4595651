// 模拟用户数据（日语）
const users = [
  {
    id: 1,
    username: "yamada",
    password: "yamada123",
    name: "山田花子"
  },
  {
    id: 2,
    username: "tanaka",
    password: "tanaka123",
    name: "田中太郎"
  },
  {
    id: 3,
    username: "suzuki",
    password: "suzuki123",
    name: "鈴木美咲"
  }
];

module.exports = users;

