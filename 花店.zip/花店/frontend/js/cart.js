// 全局变量
let cartItems = [];
let products = [];
let currentUser = null;

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    // 检查用户是否已登录
    const userStr = sessionStorage.getItem('user');
    if (!userStr) {
        window.location.href = 'login.html';
        return;
    }
    
    currentUser = JSON.parse(userStr);
    
    // 绑定事件
    document.getElementById('checkoutBtn').addEventListener('click', checkout);
    
    // 加载数据
    loadData();
});

// 加载购物车和商品数据
async function loadData() {
    try {
        // 加载商品
        const productsResponse = await fetch('http://localhost:3000/api/products');
        products = await productsResponse.json();
        
        // 加载购物车
        const cartResponse = await fetch(`http://localhost:3000/api/cart/${currentUser.id}`);
        cartItems = await cartResponse.json();
        
        displayCart();
    } catch (error) {
        console.error('Error loading data:', error);
    }
}

// 显示购物车
function displayCart() {
    const container = document.getElementById('cartContainer');
    
    if (cartItems.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 60px 20px;">
                <p style="color: #6a6a6a; font-size: 1.3rem; margin-bottom: 10px;">カートは空です</p>
                <p style="color: #999; font-size: 1rem;">商品をカートに追加してご購入ください。</p>
            </div>
        `;
        document.getElementById('totalPrice').textContent = '0';
        return;
    }
    
    let html = '<h2 style="margin-bottom: 25px;">カートの商品</h2><ul>';
    let total = 0;
    
    cartItems.forEach(item => {
        const product = products.find(p => p.id === item.productId);
        if (product) {
            const itemTotal = product.price * item.quantity;
            total += itemTotal;
            
            html += `
                <li>
                    <h3>${product.name}</h3>
                    <p>${product.description}</p>
                    <p>価格: ${product.price} 円 × ${item.quantity} = ${itemTotal} 円</p>
                    <button onclick="removeFromCart(${product.id})">削除</button>
                </li>
            `;
        }
    });
    
    html += '</ul>';
    container.innerHTML = html;
    document.getElementById('totalPrice').textContent = total;
}

// 从购物车删除商品
async function removeFromCart(productId) {
    try {
        const response = await fetch('http://localhost:3000/api/cart/remove', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id,
                productId: productId
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            cartItems = data.cart;
            displayCart();
        } else {
            alert('エラーが発生しました: ' + data.error);
        }
    } catch (error) {
        console.error('Error removing from cart:', error);
        alert('サーバーエラーが発生しました');
    }
}

// 结账
async function checkout() {
    if (cartItems.length === 0) {
        alert('カートは空です');
        return;
    }
    
    try {
        // 计算总价
        let total = 0;
        cartItems.forEach(item => {
            const product = products.find(p => p.id === item.productId);
            if (product) {
                total += product.price * item.quantity;
            }
        });
        
        // 创建订单
        const orderResponse = await fetch('http://localhost:3000/api/orders/create', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id,
                items: cartItems,
                total: total
            })
        });
        
        const orderData = await orderResponse.json();
        
        // 清空购物车
        const cartResponse = await fetch(`http://localhost:3000/api/cart/clear/${currentUser.id}`, {
            method: 'DELETE'
        });
        
        const cartData = await cartResponse.json();
        
        if (orderResponse.ok && cartResponse.ok) {
            alert('チェックアウトが完了しました！ありがとうございます！');
            cartItems = [];
            displayCart();
        } else {
            alert('エラーが発生しました: ' + (orderData.error || cartData.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error during checkout:', error);
        alert('サーバーエラーが発生しました: ' + error.message);
    }
}

