// 全局变量
let orders = [];
let currentUser = null;

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    // 检查用户是否已登录
    const userStr = sessionStorage.getItem('user');
    if (!userStr) {
        window.location.href = 'login.html';
        return;
    }
    
    currentUser = JSON.parse(userStr);
    
    // 加载订单历史
    loadOrders();
});

// 加载订单历史
async function loadOrders() {
    try {
        const response = await fetch(`http://localhost:3000/api/orders/${currentUser.id}`);
        orders = await response.json();
        displayOrders();
    } catch (error) {
        console.error('Error loading orders:', error);
    }
}

// 显示订单历史
function displayOrders() {
    const container = document.getElementById('ordersContainer');
    
    if (orders.length === 0) {
        container.innerHTML = `
            <div style="text-align: center; padding: 60px 20px;">
                <p style="color: #6a6a6a; font-size: 1.3rem; margin-bottom: 10px;">まだ注文履歴がありません。</p>
                <p style="color: #999; font-size: 1rem;">商品をご購入いただくと、ここに注文履歴が表示されます。</p>
            </div>
        `;
        return;
    }
    
    let html = '<h2 style="margin-bottom: 30px;">あなたの注文履歴</h2>';
    
    orders.forEach(order => {
        html += `
            <div class="order-card">
                <div class="order-header">
                    <h3>注文 #${order.id}</h3>
                    <span class="order-date">${order.date}</span>
                </div>
                <div class="order-items">
                    <ul>
        `;
        
        order.items.forEach(item => {
            html += `
                <li>
                    <span class="item-name">${item.productName}</span>
                    <span class="item-quantity">数量: ${item.quantity}</span>
                    <span class="item-price">${item.productPrice} 円</span>
                </li>
            `;
        });
        
        html += `
                    </ul>
                </div>
                <div class="order-total">
                    <strong>合計: ${order.total} 円</strong>
                </div>
            </div>
        `;
    });
    
    container.innerHTML = html;
}

