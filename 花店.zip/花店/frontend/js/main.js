// 全局变量
let products = [];
let currentPage = 0;
let currentUser = null;
let favorites = [];
let favoriteCounts = {};

// 初始化
document.addEventListener('DOMContentLoaded', () => {
    // 检查用户是否已登录
    const userStr = sessionStorage.getItem('user');
    if (!userStr) {
        window.location.href = 'login.html';
        return;
    }
    
    currentUser = JSON.parse(userStr);
    document.getElementById('usernameDisplay').textContent = currentUser.name;
    
    // 绑定事件
    document.getElementById('logoutBtn').addEventListener('click', logout);
    document.getElementById('cartBtn').addEventListener('click', () => {
        window.location.href = 'cart.html';
    });
    document.getElementById('ordersBtn').addEventListener('click', () => {
        window.location.href = 'orders.html';
    });
    document.getElementById('prevBtn').addEventListener('click', () => changePage(-1));
    document.getElementById('nextBtn').addEventListener('click', () => changePage(1));
    
    // 加载商品和收藏
    loadProducts();
    loadFavorites();
});

// 加载商品列表
async function loadProducts() {
    try {
        const response = await fetch('http://localhost:3000/api/products');
        products = await response.json();
        displayProduct();
    } catch (error) {
        console.error('Error loading products:', error);
    }
}

// 显示当前页的商品
async function displayProduct() {
    const container = document.getElementById('productContainer');
    const product = products[currentPage];
    
    if (!product) {
        container.innerHTML = '<p>商品が見つかりません</p>';
        return;
    }
    
    // 检查是否已收藏
    const isFavorite = favorites.includes(parseInt(product.id));
    
    // 获取收藏数
    const productIdKey = product.id.toString();
    let favoriteCount = favoriteCounts[productIdKey];
    if (!favoriteCount) {
        try {
            const response = await fetch(`http://localhost:3000/api/favorites/product/${product.id}/count`);
            const data = await response.json();
            favoriteCount = data.count;
            favoriteCounts[productIdKey] = favoriteCount;
        } catch (error) {
            favoriteCount = 0;
        }
    }
    
    container.innerHTML = `
        <div style="position: relative;">
            <div style="position: absolute; top: 0; right: 0; display: flex; flex-direction: column; align-items: flex-end; gap: 10px; z-index: 10;">
                <button onclick="toggleFavorite(${product.id})" 
                        class="favorite-heart-btn"
                        style="background: ${isFavorite ? '#d45d5d' : '#c5a892'}; width: 50px; height: 50px; border-radius: 50%; padding: 0; font-size: 1.5rem; border: none; cursor: pointer; box-shadow: 0 2px 8px rgba(139, 95, 109, 0.2); transition: all 0.3s ease;">
                    ${isFavorite ? '❤️' : '🤍'}
                </button>
                <span style="color: #8b5f6d; font-size: 0.9rem; font-weight: 500;">❤️ ${favoriteCount}人</span>
            </div>
            <h3>${product.name}</h3>
            <img src="${product.image}" alt="${product.name}" style="max-width: 300px;">
            <p>${product.description}</p>
            <p><strong>価格: ${product.price} 円</strong></p>
            <button onclick="addToCart(${product.id})" style="margin-top: 15px;">カートに追加</button>
        </div>
    `;
    
    // 更新分页信息
    document.getElementById('pageInfo').textContent = `ページ ${currentPage + 1} / ${products.length}`;
    
    // 更新按钮状态
    document.getElementById('prevBtn').disabled = currentPage === 0;
    document.getElementById('nextBtn').disabled = currentPage === products.length - 1;
}

// 切换页面
function changePage(direction) {
    const newPage = currentPage + direction;
    if (newPage >= 0 && newPage < products.length) {
        currentPage = newPage;
        displayProduct();
    }
}

// 加载收藏列表
async function loadFavorites() {
    try {
        const response = await fetch(`http://localhost:3000/api/favorites/${currentUser.id}`);
        const data = await response.json();
        favorites = data;
    } catch (error) {
        console.error('Error loading favorites:', error);
    }
}

// 切换收藏状态
async function toggleFavorite(productId) {
    try {
        const productIdInt = parseInt(productId);
        const isFavorite = favorites.includes(productIdInt);
        
        const url = `http://localhost:3000/api/favorites/${isFavorite ? 'remove' : 'add'}`;
        const method = isFavorite ? 'DELETE' : 'POST';
        
        const response = await fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id,
                productId: productIdInt
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            if (isFavorite) {
                favorites = favorites.filter(id => id !== productIdInt);
                // 减少收藏数
                const productIdKey = productIdInt.toString();
                if (favoriteCounts[productIdKey]) {
                    favoriteCounts[productIdKey] = Math.max(0, favoriteCounts[productIdKey] - 1);
                }
            } else {
                favorites.push(productIdInt);
                // 增加收藏数
                const productIdKey = productIdInt.toString();
                if (favoriteCounts[productIdKey]) {
                    favoriteCounts[productIdKey] += 1;
                } else {
                    favoriteCounts[productIdKey] = 1;
                }
            }
            displayProduct();
        } else {
            alert('エラーが発生しました: ' + (data.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Error toggling favorite:', error);
        alert('サーバーエラーが発生しました: ' + error.message);
    }
}

// 添加到购物车
async function addToCart(productId) {
    try {
        const response = await fetch('http://localhost:3000/api/cart/add', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: currentUser.id,
                productId: productId,
                quantity: 1
            })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('カートに追加しました！');
        } else {
            alert('エラーが発生しました: ' + data.error);
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        alert('サーバーエラーが発生しました');
    }
}

// 退出登录
function logout() {
    sessionStorage.removeItem('user');
    window.location.href = 'login.html';
}

