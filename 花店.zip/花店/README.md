# 花店电商网站 (Flower Shop E-commerce)

一个简单的花店电商网站，用于IT课程项目展示。实现了最小可执行单元（MVP），包含用户登录、商品展示、购物车管理等核心功能。

## 项目介绍

本项目是一个全栈电商网站，主要特点：
- **前端**: HTML + JavaScript（纯JavaScript实现）
- **后端**: Node.js + Express
- **数据存储**: 内存数组（模拟数据）
- **数据语言**: 所有模拟数据均使用日语

## 功能特性

### 1. 用户登录模块
- 用户可以通过用户名和密码登录
- 登录成功后跳转到花店首页
- 支持会话管理（sessionStorage）

### 2. 花店首页
- **商品展示**: 分页展示商品，每页显示一个商品
- **商品信息**: 显示商品名称、图片、介绍、价格
- **购物车功能**: 每个商品有"加入购物车"按钮
- **用户信息**: 右上角显示用户名和"退出登录"按钮
- **购物车按钮**: 点击跳转到购物车页面

### 3. 购物车页面
- 列出当前购物车中的所有商品
- 显示商品详细信息（名称、介绍、价格、数量）
- 提供删除商品功能
- 显示购物车总价
- 提供结账按钮，点击后弹出"结账成功"提示

### 4. 商品收藏功能（お気に入り）❤️
- 用户可以对喜欢的商品点击收藏
- 每个商品显示总收藏数（随机模拟）
- 收藏状态实时更新
- 已收藏的商品会显示不同的按钮颜色

### 5. 订单历史页面（注文履歴）🕓
- 用户可以查看自己的历史购买记录
- 显示订单日期、商品列表、数量、价格和总价
- 每个用户都有预设的默认订单记录
- 结账后自动添加到订单历史

### 6. 网站介绍
- 登录页面和首页都有美观的网站介绍区域
- 介绍内容使用日语，风格与整体设计一致

## 项目结构

```
flower-shop/
│
├─ backend/                # 后端代码
│   ├─ server.js           # 主入口
│   ├─ package.json        # 依赖配置
│   ├─ routes/             # 路由
│   │   ├─ auth.js         # 登录接口
│   │   ├─ products.js     # 商品接口
│   │   └─ cart.js         # 购物车接口
│   └─ data/               # 数据存储
│       ├─ products.js     # 商品数据
│       ├─ users.js        # 用户数据
│       └─ image/          # 商品图片
│           ├─ product_01.jpg
│           ├─ product_02.jpg
│           └─ ...
│
├─ frontend/               # 前端代码
│   ├─ index.html          # 首页
│   ├─ login.html          # 登录页
│   ├─ cart.html           # 购物车页
│   ├─ orders.html         # 订单历史页
│   ├─ css/                # CSS样式
│   │   └─ style.css       # 主样式文件
│   └─ js/                 # JS 脚本
│       ├─ main.js         # 首页逻辑
│       ├─ login.js        # 登录逻辑
│       ├─ cart.js         # 购物车逻辑
│       └─ orders.js        # 订单历史逻辑
│
├─ .gitignore              # Git忽略文件
└─ README.md               # 项目说明
```

## 安装与运行

### 1. 安装依赖

在 `backend` 目录下安装Node.js依赖：

```bash
cd backend
npm install
```

### 2. 启动后端服务器

```bash
cd backend
npm start
```

服务器将在 `http://localhost:3000` 启动

### 3. 访问前端页面

打开浏览器访问：
- 登录页: `http://localhost:3000/login.html`
- 首页: `http://localhost:3000/index.html`
- 购物车: `http://localhost:3000/cart.html`

## 测试账号

以下是可用的测试账号（所有密码都为 `用户名+123`）：

| 用户名 | 密码 | 显示名称 |
|--------|------|----------|
| yamada | yamada123 | 山田花子 |
| tanaka | tanaka123 | 田中太郎 |
| suzuki | suzuki123 | 鈴木美咲 |

## API接口

### 认证接口

#### POST /api/auth/login
用户登录

**请求体**:
```json
{
  "username": "yamada",
  "password": "yamada123"
}
```

**响应**:
```json
{
  "success": true,
  "user": {
    "id": 1,
    "username": "yamada",
    "name": "山田花子"
  }
}
```

### 商品接口

#### GET /api/products
获取所有商品列表

#### GET /api/products/:id
根据ID获取单个商品

### 购物车接口

#### GET /api/cart/:userId
获取用户购物车

#### POST /api/cart/add
添加商品到购物车

**请求体**:
```json
{
  "userId": 1,
  "productId": 1,
  "quantity": 1
}
```

#### DELETE /api/cart/remove
从购物车删除商品

**请求体**:
```json
{
  "userId": 1,
  "productId": 1
}
```

#### DELETE /api/cart/clear/:userId
清空购物车

### 收藏接口

#### GET /api/favorites/:userId
获取用户收藏的商品ID列表

#### POST /api/favorites/add
添加商品到收藏

**请求体**:
```json
{
  "userId": 1,
  "productId": 1
}
```

#### DELETE /api/favorites/remove
从收藏中删除商品

**请求体**:
```json
{
  "userId": 1,
  "productId": 1
}
```

#### GET /api/favorites/product/:productId/count
获取商品的总收藏数（随机值）

### 订单接口

#### GET /api/orders/:userId
获取用户订单历史

#### POST /api/orders/create
创建新订单

**请求体**:
```json
{
  "userId": 1,
  "items": [{"productId": 1, "quantity": 2}],
  "total": 7000
}
```

## 技术栈

- **后端**: Node.js, Express, CORS
- **前端**: HTML5, JavaScript (ES6+)
- **数据存储**: 内存数组

## 样式设计

本项目采用浅色系配色方案：
- **主色调**: 米白色、淡粉色、浅绿色
- **文字颜色**: 深灰色，确保良好的可读性
- **布局**: 灵活的网格系统，留白充足
- **设计元素**: 圆角按钮和容器，平滑的过渡效果
- **响应式**: 支持桌面、平板和移动设备

## 注意事项

1. 本项目为MVP版本，专注于功能实现和美观的UI设计
2. 所有数据存储在内存中，服务器重启后数据会丢失
3. 本项目仅用于学习展示，不适合生产环境使用
4. 商品图片位于 `backend/data/image/` 文件夹中

## 未来改进

- [x] 添加CSS样式美化界面
- [x] 添加商品收藏功能
- [x] 添加订单历史记录
- [x] 添加网站介绍区域
- [ ] 使用数据库持久化数据
- [ ] 添加商品搜索功能
- [ ] 添加商品分类功能
- [ ] 添加支付功能
- [ ] 添加用户注册功能
- [ ] 添加图片上传功能

## 许可证

本项目仅用于教育和学习目的。

